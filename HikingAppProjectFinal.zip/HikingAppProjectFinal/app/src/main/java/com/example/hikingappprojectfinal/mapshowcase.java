package com.example.hikingappprojectfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class mapshowcase extends AppCompatActivity {

    ImageButton homebutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapshowcase);

        homebutton = (ImageButton) findViewById(R.id.imageView);
        homebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returnlast();
            }
        });
    }

    public void returnlast(){
        Intent intent = new Intent(this, mappageselect.class);
        startActivity(intent);
    }
}