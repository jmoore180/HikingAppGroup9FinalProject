package com.example.hikingappprojectfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DeleteMap extends AppCompatActivity {

    Button returnbutton;
    Button mapbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_map);

        returnbutton = (Button) findViewById(R.id.button4);
        returnbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goback();
            }
        });
        mapbutton = (Button) findViewById(R.id.pw_setting);
        mapbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delex();
            }
        });
    }


    public void goback(){
        Intent intent = new Intent(this, mappageselect.class);
        startActivity(intent);
    }
    public void delex(){
        Intent intent = new Intent(this, mappageselectempty.class);
        startActivity(intent);
    }
}