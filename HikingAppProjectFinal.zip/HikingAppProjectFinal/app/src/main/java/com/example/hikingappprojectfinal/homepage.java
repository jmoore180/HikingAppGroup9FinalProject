package com.example.hikingappprojectfinal;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.ImageButton;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class homepage extends AppCompatActivity {

    ImageButton homebutton;
    ImageButton mapicon;
    ImageButton mapicon2;
    ImageButton infoicon;
    ImageButton setticon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        homebutton = (ImageButton) findViewById(R.id.home_high_hs);
        homebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLogin();
            }
        });

        mapicon = (ImageButton) findViewById(R.id.map_unhigh_hs);
        mapicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMap();
            }
        });

        infoicon = (ImageButton) findViewById(R.id.alert_circle_unhigh);
        infoicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openinfo();
            }
        });

        setticon = (ImageButton) findViewById(R.id.settings);
        setticon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opensett();
            }
        });
        mapicon2= (ImageButton) findViewById(R.id.map_hs);
        mapicon2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMap();
            }
        });
    }

   public void openLogin(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void openMap(){
        Intent intent = new Intent(this, mappage.class);
        startActivity(intent);
    }
    public void openinfo(){
        Intent intent = new Intent(this, infoscreen.class);
        startActivity(intent);
    }
    public void opensett(){
        Intent intent = new Intent(this, settingpage.class);
        startActivity(intent);
    }
}